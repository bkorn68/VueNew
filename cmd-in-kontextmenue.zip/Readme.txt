Quelle der REG-Datei: Microsoft
https://blogs.msdn.microsoft.com/andrew_richards/2017/03/01/enhancing-the-open-command-prompt-here-shift-right-click-context-menu-experience/

Quelle der Bearbeitung und Deutsche �bersetzung: GIGA
http://www.giga.de/downloads/windows-10/tipps/windows-10-wieder-die-eingabeaufforderung-statt-powershell-benutzen/



