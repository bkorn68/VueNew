﻿using System;

namespace AdventureWorksAPI.ViewModels
{
    public class ProductViewModel
    {
        public Int32? ProductID { get; set; }

        public String ProductName { get; set; }

        public String ProductNumber { get; set; }
    }
}
