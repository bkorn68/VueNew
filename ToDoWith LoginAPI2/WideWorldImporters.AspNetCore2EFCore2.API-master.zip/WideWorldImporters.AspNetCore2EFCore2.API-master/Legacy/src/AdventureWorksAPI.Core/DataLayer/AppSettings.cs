﻿using System;

namespace AdventureWorksAPI.Core.DataLayer
{
    public class AppSettings
    {
        public String ConnectionString { get; set; }
    }
}
