# Wide World Importers ASP.NET Core API

ASP.NET Core API Sample developed with ASP.NET Core 2 and Entity Framework Core 2.

[`Creating Web API in ASP.NET Core 2.0`](https://www.codeproject.com/Articles/1264219/Creating-Web-API-in-ASP-NET-Core-2-0)
